public class browserSession 
{
}
