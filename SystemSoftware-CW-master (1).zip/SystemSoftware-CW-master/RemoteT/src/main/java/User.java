public class User {
    private String userName;
    private String password;
    private boolean userType;

    public String changepassword(String username){

        return username;
    };

    public String getUserName() {return userName;};
    public String getPassword() {return password;};
    public boolean getUserType() {return userType;};
    public void removeUser(String username)
    {

    };
    public void addUser(boolean usertype, String username)
    {

    };
}
